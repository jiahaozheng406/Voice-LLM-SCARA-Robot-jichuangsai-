Total 378 images

 classes
Eraser,
scale, 
pencil, 
sharpener
paper

labeled using labelimg tool

all 350 images taken from google